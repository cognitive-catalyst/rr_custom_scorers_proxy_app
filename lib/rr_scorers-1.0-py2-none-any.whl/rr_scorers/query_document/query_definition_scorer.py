"""
	If a question is a definition, score the extent to which there exists a single passage that answers that
	question
"""

# Metadata
__author__ = 'Vincent Dowling'
__email__ = 'vdowlin@us.ibm.com'

# Standard imports
import re

# 3rd party imports
from spacy.en import English

# Local imports
import query_document_scorer as qds


class WhatIsScorer(qds.QueryDocumentScorer):
	def __init__(self, name='WhatIsScorer', description='', short_name='wis', strategy='max'):
		""" If a question is of the form 'what is X' score the extent to which a single sentence
			in the answer is of the form 'X is ...'

			args:
				name, description, short_name (str): See qds.QueryDocumentScorer
				strategy (str): The scoring strategy. Must be one of the following: 'max', 'average'
		"""
		super(WhatIsScorer, self).__init__(name=name, description=description, short_name=short_name)
		self.strategy = strategy
		self.nlp = English()

	def mean(self, iterable):
		n = len(iterable)
		s = sum(iterable)
		return s / float(n)

	def score(self, query, document):
		""" Score the definition overlap of the sentence
		"""
		qt = query['q'] # query text
		qtm = re.match('^what is (.*)$', qt.lower())
		if qtm:
			qr = qtm.group(1) # query remainder
			dt = self.nlp(unicode(document['text']))
			ss = list() # sentence scores
			for sent in dt.sents:
				amt = '^%s (?:is|are|am|was) .*$' % qr # answer matcher text
				ss.append(1.0 if re.match(amt, sent.orth_.lower()) else 0.0)
			return self.mean(ss) if self.strategy == 'average' else max(ss)
		else:
			return 0.0
# endclass WhatIsScorer
